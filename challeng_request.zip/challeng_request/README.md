# Workout Logging Flow

 focus on:

- Layout & visual polish
- Animation & interaction flow
- Architecture & SwiftUI best practices
- How you think and explain your work

---

## 🎯 The Task

Recreate the workout logging flow shown in `Demo Screen Exports`.

You are not expected to perfectly replicate the mockup — we’re interested in how you interpret incomplete design direction, and how you bring it to life in code and UI.

---

## 🧩 Requirements

### Core Flow:

1. Tap `Start` to begin the workout
2. Enter `Kg` and `Reps` for each set
3. Tap to complete a set and start a rest timer
4. Finish all sets to see a summary screen

### Key Component — 🔥 Pill Animation

- The pill-shaped button at the bottom ("Start") should **fluidly animate** to become the keyboard, timer etc (This is important and a key factor we're looking at).

Animate through these states:

- Start → Timer + Finish
- Timer → Number Pad
- Number Pad → Rest Timer Picker
- Rest Timer Picker → Countdown

### Additional:

- Tapping inputs should open a custom number pad
- Rest timer lets users pick (30s, 1m, etc.), then shows a progress bar
- Summary screen displays completed set data

---

## ⚙️ Tech Expectations

Use:

- **SwiftUI only**
- MVVM (or other clean architecture)
- Thoughtful use of `@State`, `ObservableObject`, etc.
- Clean, reusable components

---

## 🧪 Bonus Points 

- Unit tests for logic
- Snapshot/UI tests
- Accessibility support
- README

---
